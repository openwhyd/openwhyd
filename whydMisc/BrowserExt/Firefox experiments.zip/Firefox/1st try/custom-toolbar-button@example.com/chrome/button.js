CustomButton = {

1: function () {
  alert("Just testing")	
  },

}